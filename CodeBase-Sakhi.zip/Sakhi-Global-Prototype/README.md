# Sakhi Global Clickable Prototype

Sakhi is a standalone clickable wellness prototype created for Microsoft Global Hackathon 2026.

## Run locally
Open `index.html` in a modern browser such as Microsoft Edge or Google Chrome. No build step or package installation is required.

## Repository structure
- `index.html` - complete prototype with embedded HTML, CSS, JavaScript, and image assets.
- `LICENSE` - MIT license template for repository use.
- `.gitignore` - common editor and operating-system exclusions.

## Prototype areas
The current prototype includes welcome/sign-in, country and language selection, home navigation, conversational guidance, nearby-care discovery, dietary guidance, learning content, saved/offline guidance, and appointment flows.

## Safety note
This is a hackathon prototype and is not a substitute for professional medical care, diagnosis, treatment, or emergency services.
